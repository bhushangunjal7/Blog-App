(function () {
        //adding spaces to test minify


    jQuery(document).ready(function () {

        var abc = "DFDF";




        console.log(abc);











        console.log(abc);


        console.log(abc);


    });

})();
