(function () {
        //adding spaces to test minify


    jQuery(document).ready(function () {

        var abc = "Custom";




        console.log(abc);



    });

})();
