package gt.app.modules.note.dto;

public record NoteEditDto(Long id, String title, String content) {
}
